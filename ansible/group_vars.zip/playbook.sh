#!/bin/bash

###############################################################################################################
#Asumption  about Ansible Master/Controle Machine                                                             #
# 1) install Ansline AWS-EC2Plugin                                                                            #
# ansible-galaxy collection install amazon.aws                                                                #
#                                                                                                             #
# 2) Follwing entry added in /etc/ansible/ansible.cfg                                                         #
# [inventory]                                                                                                 #
# enable_plugins = aws_ec2, host_list, script, auto, yaml, ini, toml#                                         #
#                                                                                                             #
# 3) folwing pachnages are installaed on Ansible Master/Controle Machine                                      #
#sudo yum install -y python3                                                                                  #
#sudo pip3 install --user boto3                                                                               #
#3) Aws cli is installed  AWS IAM  user key and id configured with default profile                            #
#                                                                                                             #
#                                                                                                             #
#                                                                                                             #
###############################################################################################################


ansible-playbook --private-key ec2_user.pem -i inventory_aws_ec2.yml playbook.yml